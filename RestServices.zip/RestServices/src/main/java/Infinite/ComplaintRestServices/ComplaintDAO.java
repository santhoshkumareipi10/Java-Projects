package Infinite.ComplaintRestServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;


public class ComplaintDAO {
	
	 PreparedStatement pst;   
	 Connection connection;

	 public String addComplaint(Complaint complaint) throws ClassNotFoundException, SQLException {
		connection=ConnectionHelper.getConnection();
		 String cmd="Insert into Complaint(ComplaintID,ComplaintType,CDescription,ComplaintDate,Severity,Status)values(?,?,?,?,?,?)";
		 pst=connection.prepareStatement(cmd);
		 pst.setInt(1,complaint.getCompid());
		 pst.setString(2, complaint.getComptype());
		 pst.setString(3, complaint.getCompdesc());
		 pst.setDate(4, complaint.getCompdate());
		 pst.setString(5, complaint.getServ());
		 pst.setString(6, complaint.getStatus());
		 pst.executeUpdate();
		 return "Complaint Raised Sucessfully";
	 } 
	 public Complaint searchComplaint(int ComplaintID) throws ClassNotFoundException, SQLException {
		 connection= ConnectionHelper.getConnection();
		 String cmd="Select * from Complaint where ComplaintID=?";
		 pst=connection.prepareStatement(cmd);
		 pst.setInt(1, ComplaintID);
		 ResultSet rs = pst.executeQuery();
		 
		 Complaint complaint=null;
		 
		 if(rs.next()) {
			 complaint= new Complaint();
			 complaint.setCompid(rs.getInt("ComplaintID"));
			 complaint.setComptype(rs.getString("ComplaintType"));
			 complaint.setCompdate(rs.getDate("ComplaintDate"));
			 complaint.setCompdesc(rs.getString("CDescription"));
			 complaint.setServ(rs.getString("Severity"));
			 complaint.setStatus(rs.getString("Status"));
			 
		 }
		 return complaint;
	 }
	 
	 public Complaint[] ShowComplaint() throws ClassNotFoundException, SQLException {
			connection=ConnectionHelper.getConnection();
			List<Complaint> complaintList = new ArrayList<Complaint>();
			String cmd = "select * from Complaint" ;
			pst=connection.prepareStatement(cmd);
			ResultSet rs= pst.executeQuery();
			Complaint complaint = new Complaint();
			while(rs.next()) {
				complaint = new Complaint();
				complaint.setCompid(rs.getInt("ComplaintId"));
				complaint.setComptype(rs.getString("ComplaintType"));
				complaint.setCompdesc(rs.getString("CDescription"));
				complaint.setCompdate(rs.getDate("ComplaintDate"));
				complaint.setServ(rs.getString("Severity"));
				complaint.setStatus(rs.getString("Status"));
				complaintList.add(complaint);
			}
			return complaintList.toArray(new Complaint[complaintList.size()]);
		}
	
}
