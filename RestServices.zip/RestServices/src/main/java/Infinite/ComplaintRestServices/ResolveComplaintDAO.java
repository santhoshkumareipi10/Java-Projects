package Infinite.ComplaintRestServices;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class ResolveComplaintDAO {
	  Connection connection;
	  PreparedStatement pst;
	 
	
	  public String addResolved(ResolveComplaint rc) throws ClassNotFoundException, SQLException {
			connection=ConnectionHelper.getConnection();
			 String cmd="Insert into resolve(ComplaintID, ComplaintDate, ResolveDate, ResolvedBy, Comments)values(?,?,?,?,?)";
			 pst=connection.prepareStatement(cmd);
			 pst.setInt(1,rc.getCompid());
			 pst.setDate(2, rc.getCompdate());
			 pst.setDate(3, rc.getResdate());
			 pst.setString(4, rc.getResby());
			 pst.setString(5, rc.getComm());
			 pst.executeUpdate();
			 cmd="Update Complaint set Status='Resolved' where ComplaintID=?";
				pst=connection.prepareStatement(cmd);
				pst.setInt(1, rc.getCompid());
				pst.executeUpdate();
				
				return "Complaint Resolved";
			 
		 }
	  
	

}
