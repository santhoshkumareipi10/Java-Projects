package Infinite.ComplaintRestServices;

import java.sql.Date;

public class ResolveComplaint {
private int compid;
private Date compdate;
private Date resdate;
private String resby;
private String comm;


public int getCompid() {
	return compid;
}
public void setCompid(int compid) {
	this.compid = compid;
}
public Date getCompdate() {
	return compdate;
}
public void setCompdate(Date compdate) {
	this.compdate = compdate;
}
public Date getResdate() {
	return resdate;
}
public void setResdate(Date resdate) {
	this.resdate = resdate;
}
public String getResby() {
	return resby;
}
public void setResby(String resby) {
	this.resby = resby;
}
public String getComm() {
	return comm;
}
public void setComm(String comm) {
	this.comm = comm;
}
	
}
