package com.example.demo;

public enum OrdStatus {
	ACCEPTED,DENIED,CANCELLED,PENDING
}
