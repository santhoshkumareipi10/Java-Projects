package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
public class Menu {
	@Id
	private int menuId;
	private String menuItem;
	private double menuPrice;
	private double menuCalories;
	private String menuType;
	
	@Enumerated(EnumType.STRING)
	private MenuStatus menuStatus;
	private int menuRating;
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public String getMenuItem() {
		return menuItem;
	}
	public void setMenuItem(String menuItem) {
		this.menuItem = menuItem;
	}
	public double getMenuPrice() {
		return menuPrice;
	}
	public void setMenuPrice(double menuPrice) {
		this.menuPrice = menuPrice;
	}
	public double getMenuCalories() {
		return menuCalories;
	}
	public void setMenuCalories(double menuCalories) {
		this.menuCalories = menuCalories;
	}
	public String getMenuType() {
		return menuType;
	}
	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}
	public MenuStatus getMenuStatus() {
		return menuStatus;
	}
	public void setMenuStatus(MenuStatus menuStatus) {
		this.menuStatus = menuStatus;
	}
	public int getMenuRating() {
		return menuRating;
	}
	public void setMenuRating(int menuRating) {
		this.menuRating = menuRating;
	}
	public Menu() {
		
		// TODO Auto-generated constructor stub
	}
	public Menu(int menuId, String menuItem, double menuPrice, double menuCalories, String menuType,
			MenuStatus menuStatus, int menuRating) {
		
		this.menuId = menuId;
		this.menuItem = menuItem;
		this.menuPrice = menuPrice;
		this.menuCalories = menuCalories;
		this.menuType = menuType;
		this.menuStatus = menuStatus;
		this.menuRating = menuRating;
	}
	
	
}
