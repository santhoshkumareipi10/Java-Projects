package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class CustomerService {

	@Autowired
	private CustomerRepo repo;
	
	@Autowired
	private Customerdao dao;
	
	public String auth(String name,String pwd) {
		return dao.authenticate(name, pwd);
	}
	
	public List<Customer> showCustomer(){
		return repo.findAll();
	}
	
	public Customer search(int cid) {
		return repo.findById(cid).get();
	}
}
