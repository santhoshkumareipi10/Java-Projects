package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDAO {

	@Autowired  
    JdbcTemplate jdbc; 
	
	public void updateleavebal(int empno, int leaveBalance) {
		String cmd =  "Update Employee set EMP_AVAIL_LEAVE_BAL=? WHERE EMP_ID=?";
		jdbc.update(cmd, new Object[] {leaveBalance, empno});
	
	}
	
	public void updateleavebal_ondeny(int empno, int leaveBalance) {
		String cmd = "UPDATE EMPLOYEE SET EMP_AVAIL_LEAVE_BAL=EMP_AVAIL_LEAVE_BAL+? "
				+ " WHERE EMP_ID=?";
		jdbc.update(cmd, new Object[] {leaveBalance, empno});
	
	}
}
