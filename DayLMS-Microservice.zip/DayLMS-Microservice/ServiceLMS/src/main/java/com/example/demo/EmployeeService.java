package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class EmployeeService {

	@Autowired
	private EmployeeRepo repo;
	
	public List<Employee> showEmployee(){
		return repo.findAll();
	}
	
	public Employee search(int cid) {
		return repo.findById(cid).get();
	}
}
