package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class LeaveDetailsDAO {

	@Autowired  
    JdbcTemplate jdbc; 
	
	
	@SuppressWarnings("deprecation")
	public List<LeaveDetails> showlh(int empno) {
		String cmd = "select * from Leave_History where EMP_ID=?";
		List<LeaveDetails> lhList=null;
		lhList=jdbc.query(cmd,new Object[] {empno}, new RowMapper<LeaveDetails>() {

			@Override
			public LeaveDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				LeaveDetails ld = new LeaveDetails();
				ld.setLeaveId(rs.getInt("LEAVE_ID"));
				ld.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				ld.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
				ld.setEmpId(rs.getInt("EMP_ID"));
				ld.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				ld.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				ld.setLeaveType(rs.getString("LEAVE_TYPE"));
				ld.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				ld.setLeaveReason(rs.getString("LEAVE_REASON"));
				return ld;
			}
			
		});
		return lhList;
	}
	
	
	@SuppressWarnings("deprecation")
	public List<LeaveDetails> showpending(int empno) {
		String cmd = "select * from Leave_History where EMP_ID=? AND LEAVE_STATUS='PENDING'";
		List<LeaveDetails> lhList=null;
		lhList=jdbc.query(cmd,new Object[] {empno}, new RowMapper<LeaveDetails>() {

			@Override
			public LeaveDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				LeaveDetails ld = new LeaveDetails();
				ld.setLeaveId(rs.getInt("LEAVE_ID"));
				ld.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				ld.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
				ld.setEmpId(rs.getInt("EMP_ID"));
				ld.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				ld.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				ld.setLeaveType(rs.getString("LEAVE_TYPE"));
				ld.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				ld.setLeaveReason(rs.getString("LEAVE_REASON"));
				return ld;
			}
			
		});
		return lhList;
	}
	
	
	public void updatestatus(String leaveStatus, String comm, int leaveid) {
		String cmd = "Update leave_history SET LEAVE_STATUS=?, "
				+ "LEAVE_MNGR_COMMENTS=? where LEAVE_ID=?";
		jdbc.update(cmd, new Object[] {leaveStatus, comm, leaveid});
	}
}
