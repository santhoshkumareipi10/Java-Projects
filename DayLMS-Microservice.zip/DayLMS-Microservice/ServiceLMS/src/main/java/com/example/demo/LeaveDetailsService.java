package com.example.demo;

import java.sql.Date;
import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveDetailsService {

	@Autowired
	private LeaveDetailsRepo repo;
	
	@Autowired
	LeaveDetailsDAO lddao;
	
	@Autowired
	EmployeeDAO empdao;
	
	public String applyLeave(int empno, Date leaveStartDate, Date leaveEndDate, String leaveReason) {
		System.out.println(leaveEndDate);
		System.out.println(leaveStartDate);
		

		 long ms = leaveEndDate.getTime()- leaveStartDate.getTime();
		    long m = ms / (1000 * 24 * 60 * 60);
		    int days = (int) m;
		    days = days + 1;
		    
		    Employee employee = new EmployeeService().search(empno);
		    int leaveBalance = employee.getEmpAvailLeaveBal();
		    if (days < 0) {
		    	return "Leave-Start Date Cannot be Greater than leave-End Date...";
		    } else if (leaveBalance-days < 0) {
		    	return "Insufficient Leave Balance...";
		    } else {
		    	int diff = leaveBalance-days;
		    	
		    	LeaveDetails leaveDetails = new LeaveDetails();
		    	
		    	leaveDetails.setLeaveNoOfDays(days);
		    	leaveDetails.setLeaveType("EL");
			    leaveDetails.setLeaveStatus("PENDING");
			    leaveDetails.setLeaveStartDate(leaveStartDate);
		    	leaveDetails.setLeaveEndDate(leaveEndDate);
		    	leaveDetails.setEmpId(empno);
		    	leaveDetails.setLeaveReason(leaveReason);
		    	
		    	repo.save(leaveDetails);
		    	empdao.updateleavebal(empno, diff);
		    	
		    	return "Leave Applied Successfully...";
		    }
		
	}
	
	
	
	public String approveordeny(int leaveid, int mgrid, String managerComments, String status) {
		
		LeaveDetails leaveDetails = searchlid(leaveid);
	
		Employee emp = new EmployeeService().search(leaveDetails.getEmpId());
		int empId=leaveDetails.getEmpId();
		int noOfDays = leaveDetails.getLeaveNoOfDays();
		
		if (mgrid==emp.getEmpManagerId()) {
			if (status.toUpperCase().equals("YES")) {
				lddao.updatestatus("APPROVED", managerComments, leaveid);
				return "Your Leave Approved...";
			} else {
				lddao.updatestatus("DENIED", managerComments, leaveid);
				
				empdao.updateleavebal_ondeny(empId, noOfDays);
				
				return "Your Leave not Approved...";
			}
		} else {
			return "You Are Unauthorized Manager...";
		}
	}
	
	public LeaveDetails searchlid(int lid) {
		return repo.findById(lid).get();
	}
	
	public List<LeaveDetails> showleavehistory(int empno){
		return lddao.showlh(empno);
	}
	
	public List<LeaveDetails> showleavepending(int empno){
		return lddao.showpending(empno);
	}
}
