package com.example.demo;

import java.sql.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveDetailsController {

	@Autowired
	private LeaveDetailsService ldserv;
	
	@RequestMapping(value="/showlh/{empno}")
	public List<LeaveDetails> leavehistory(@PathVariable int empno) {
		return ldserv.showleavehistory(empno);
	}
	
	@RequestMapping(value="/showpl/{empno}")
	public List<LeaveDetails> pendingleaves(@PathVariable int empno) {
		return ldserv.showleavepending(empno);
	}
	
	@RequestMapping(value="/searchlid/{lid}")
	public LeaveDetails searchlid(@PathVariable int lid) {
		return ldserv.searchlid(lid);
	}
	
	
	
	
	
	/*
	
	// PostMapping Not Done
	
	
	@PostMapping("/applyleave/{lid}/{sdate}/{edate}/{lreason}")
	public String applyLeave(@PathVariable int lid, Date sdate, Date edate, String lreason) {
		return ldserv.applyLeave(lid, sdate, edate, lreason);
	}
	
	@PostMapping("/approvedeny/{lid}/{mgrid}/{mgrcomm}/{status}")
	public String approvedeny(@PathVariable int lid, int mgrid, String mgrcomm, String status) {
		return ldserv.approveordeny(lid, mgrid, mgrcomm, status);
	}
	
	
	*/
	
	
}
