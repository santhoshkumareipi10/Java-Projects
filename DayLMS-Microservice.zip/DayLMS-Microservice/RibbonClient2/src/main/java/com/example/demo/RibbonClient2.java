package com.example.demo;

import java.io.IOException;
import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@RestController
public class RibbonClient2 {

	@Autowired
	private LoadBalancerClient lba;
	
	private static HttpEntity<?> getHeaders() throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}
	
	@GetMapping(value= "/showEmploy")
	public Object[] showEmplly() throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("servicelms");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showemp";

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		ResponseEntity<Object[]> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object[].class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + res.getBody());
		return res.getBody();
	}
	
	@GetMapping(value= "/showEmploy/{id}")
	public Object searchEmploy(@PathVariable int id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("servicelms");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showemp/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		ResponseEntity<Object> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object.class);
		//	response= restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + res.getBody());
		return res.getBody();
	}
	
	@GetMapping(value= "/lh/{id}")
	public Object leavehistory(@PathVariable int id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("servicelms");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showlh/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		ResponseEntity<Object> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + res.getBody());
		return res.getBody();
	}
	
	@GetMapping(value= "/pl/{id}")
	public Object pendingleave(@PathVariable int id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("servicelms");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/showpl/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		ResponseEntity<Object> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + res.getBody());
		return res.getBody();
	}
	
	@GetMapping(value= "/lid/{id}")
	public Object searchleaveid(@PathVariable int id) throws RestClientException, IOException {
		ServiceInstance servInstance= lba.choose("servicelms");
		System.out.println("HI " +servInstance.getUri());

		String baseUrl= servInstance.getUri().toString();
		baseUrl= baseUrl + "/searchlid/"+id;

		RestTemplate restTemplate= new RestTemplate();
		ResponseEntity<String> response= null;
		
		ResponseEntity<Object> res=null;
		try{
			res = restTemplate.exchange(baseUrl, HttpMethod.GET,getHeaders(),Object.class);
		} catch (Exception ex) {
			System.out.println("Exception " +ex);
		}
		System.out.println("Output= " + res.getBody());
		return res.getBody();
	}
	
	
}
