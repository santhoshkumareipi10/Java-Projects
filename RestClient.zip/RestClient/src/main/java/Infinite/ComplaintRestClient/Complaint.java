package Infinite.ComplaintRestClient;
import java.sql.Date;


public class Complaint {

	private int compid;
	private String comptype;
	private String compdesc;
	private String serv;
	private String status;
	private Date compdate;
	
	
	public Complaint() {
		
	}
	
	
	public Complaint(int compid, String comptype, String compdesc, String serv, String status, Date compdate) {
		
		this.compid = compid;
		this.comptype = comptype;
		this.compdesc = compdesc;
		this.serv = serv;
		this.status = status;
		this.compdate = compdate;
	}


	public int getCompid() {
		return compid;
	}
	public void setCompid(int compid) {
		this.compid = compid;
	}
	public String getComptype() {
		return comptype;
	}
	public void setComptype(String comptype) {
		this.comptype = comptype;
	}
	public String getCompdesc() {
		return compdesc;
	}
	public void setCompdesc(String compdesc) {
		this.compdesc = compdesc;
	}
	public String getServ() {
		return serv;
	}
	public void setServ(String serv) {
		this.serv = serv;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCompdate() {
		return compdate;
	}
	public void setCompdate(Date compdate) {
		this.compdate = compdate;
	}
	
	
	
}
