/**
 * Complaint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Infinite.ComplaintRestServices;

public class Complaint  implements java.io.Serializable {
    private java.util.Date compdate;

    private java.lang.String compdesc;

    private int compid;

    private java.lang.String comptype;

    private java.lang.String serv;

    private java.lang.String status;

    public Complaint() {
    }

    public Complaint(
           java.util.Date compdate,
           java.lang.String compdesc,
           int compid,
           java.lang.String comptype,
           java.lang.String serv,
           java.lang.String status) {
           this.compdate = compdate;
           this.compdesc = compdesc;
           this.compid = compid;
           this.comptype = comptype;
           this.serv = serv;
           this.status = status;
    }


    /**
     * Gets the compdate value for this Complaint.
     * 
     * @return compdate
     */
    public java.util.Date getCompdate() {
        return compdate;
    }


    /**
     * Sets the compdate value for this Complaint.
     * 
     * @param compdate
     */
    public void setCompdate(java.util.Date compdate) {
        this.compdate = compdate;
    }


    /**
     * Gets the compdesc value for this Complaint.
     * 
     * @return compdesc
     */
    public java.lang.String getCompdesc() {
        return compdesc;
    }


    /**
     * Sets the compdesc value for this Complaint.
     * 
     * @param compdesc
     */
    public void setCompdesc(java.lang.String compdesc) {
        this.compdesc = compdesc;
    }


    /**
     * Gets the compid value for this Complaint.
     * 
     * @return compid
     */
    public int getCompid() {
        return compid;
    }


    /**
     * Sets the compid value for this Complaint.
     * 
     * @param compid
     */
    public void setCompid(int compid) {
        this.compid = compid;
    }


    /**
     * Gets the comptype value for this Complaint.
     * 
     * @return comptype
     */
    public java.lang.String getComptype() {
        return comptype;
    }


    /**
     * Sets the comptype value for this Complaint.
     * 
     * @param comptype
     */
    public void setComptype(java.lang.String comptype) {
        this.comptype = comptype;
    }


    /**
     * Gets the serv value for this Complaint.
     * 
     * @return serv
     */
    public java.lang.String getServ() {
        return serv;
    }


    /**
     * Sets the serv value for this Complaint.
     * 
     * @param serv
     */
    public void setServ(java.lang.String serv) {
        this.serv = serv;
    }


    /**
     * Gets the status value for this Complaint.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Complaint.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Complaint)) return false;
        Complaint other = (Complaint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.compdate==null && other.getCompdate()==null) || 
             (this.compdate!=null &&
              this.compdate.equals(other.getCompdate()))) &&
            ((this.compdesc==null && other.getCompdesc()==null) || 
             (this.compdesc!=null &&
              this.compdesc.equals(other.getCompdesc()))) &&
            this.compid == other.getCompid() &&
            ((this.comptype==null && other.getComptype()==null) || 
             (this.comptype!=null &&
              this.comptype.equals(other.getComptype()))) &&
            ((this.serv==null && other.getServ()==null) || 
             (this.serv!=null &&
              this.serv.equals(other.getServ()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCompdate() != null) {
            _hashCode += getCompdate().hashCode();
        }
        if (getCompdesc() != null) {
            _hashCode += getCompdesc().hashCode();
        }
        _hashCode += getCompid();
        if (getComptype() != null) {
            _hashCode += getComptype().hashCode();
        }
        if (getServ() != null) {
            _hashCode += getServ().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Complaint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "Complaint"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compdate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "compdate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compdesc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "compdesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "compid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comptype");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "comptype"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serv");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "serv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
