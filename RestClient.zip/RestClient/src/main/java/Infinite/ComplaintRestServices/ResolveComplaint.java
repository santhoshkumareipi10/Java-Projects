/**
 * ResolveComplaint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Infinite.ComplaintRestServices;

public class ResolveComplaint  implements java.io.Serializable {
    private java.lang.String comm;

    private java.util.Date compdate;

    private int compid;

    private java.lang.String resby;

    private java.util.Date resdate;

    public ResolveComplaint() {
    }

    public ResolveComplaint(
           java.lang.String comm,
           java.util.Date compdate,
           int compid,
           java.lang.String resby,
           java.util.Date resdate) {
           this.comm = comm;
           this.compdate = compdate;
           this.compid = compid;
           this.resby = resby;
           this.resdate = resdate;
    }


    /**
     * Gets the comm value for this ResolveComplaint.
     * 
     * @return comm
     */
    public java.lang.String getComm() {
        return comm;
    }


    /**
     * Sets the comm value for this ResolveComplaint.
     * 
     * @param comm
     */
    public void setComm(java.lang.String comm) {
        this.comm = comm;
    }


    /**
     * Gets the compdate value for this ResolveComplaint.
     * 
     * @return compdate
     */
    public java.util.Date getCompdate() {
        return compdate;
    }


    /**
     * Sets the compdate value for this ResolveComplaint.
     * 
     * @param compdate
     */
    public void setCompdate(java.util.Date compdate) {
        this.compdate = compdate;
    }


    /**
     * Gets the compid value for this ResolveComplaint.
     * 
     * @return compid
     */
    public int getCompid() {
        return compid;
    }


    /**
     * Sets the compid value for this ResolveComplaint.
     * 
     * @param compid
     */
    public void setCompid(int compid) {
        this.compid = compid;
    }


    /**
     * Gets the resby value for this ResolveComplaint.
     * 
     * @return resby
     */
    public java.lang.String getResby() {
        return resby;
    }


    /**
     * Sets the resby value for this ResolveComplaint.
     * 
     * @param resby
     */
    public void setResby(java.lang.String resby) {
        this.resby = resby;
    }


    /**
     * Gets the resdate value for this ResolveComplaint.
     * 
     * @return resdate
     */
    public java.util.Date getResdate() {
        return resdate;
    }


    /**
     * Sets the resdate value for this ResolveComplaint.
     * 
     * @param resdate
     */
    public void setResdate(java.util.Date resdate) {
        this.resdate = resdate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResolveComplaint)) return false;
        ResolveComplaint other = (ResolveComplaint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.comm==null && other.getComm()==null) || 
             (this.comm!=null &&
              this.comm.equals(other.getComm()))) &&
            ((this.compdate==null && other.getCompdate()==null) || 
             (this.compdate!=null &&
              this.compdate.equals(other.getCompdate()))) &&
            this.compid == other.getCompid() &&
            ((this.resby==null && other.getResby()==null) || 
             (this.resby!=null &&
              this.resby.equals(other.getResby()))) &&
            ((this.resdate==null && other.getResdate()==null) || 
             (this.resdate!=null &&
              this.resdate.equals(other.getResdate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getComm() != null) {
            _hashCode += getComm().hashCode();
        }
        if (getCompdate() != null) {
            _hashCode += getCompdate().hashCode();
        }
        _hashCode += getCompid();
        if (getResby() != null) {
            _hashCode += getResby().hashCode();
        }
        if (getResdate() != null) {
            _hashCode += getResdate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResolveComplaint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "ResolveComplaint"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "comm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compdate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "compdate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "compid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resby");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "resby"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resdate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "resdate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
