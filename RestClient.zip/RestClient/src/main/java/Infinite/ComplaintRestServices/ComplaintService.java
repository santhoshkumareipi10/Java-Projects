/**
 * ComplaintService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Infinite.ComplaintRestServices;

public interface ComplaintService extends java.rmi.Remote {
    public Infinite.ComplaintRestServices.Complaint[] showComplaint() throws java.rmi.RemoteException;
    public Infinite.ComplaintRestServices.Complaint showComplaint(int complaintID) throws java.rmi.RemoteException;
    public java.lang.String addResolved(Infinite.ComplaintRestServices.ResolveComplaint rc) throws java.rmi.RemoteException;
    public java.lang.String addComplaint(Infinite.ComplaintRestServices.Complaint complaint) throws java.rmi.RemoteException;
}
