/**
 * CompService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.java.restservices.RestComplaintService;

public interface CompService extends java.rmi.Remote {
    public com.java.restservices.RestComplaintService.Complaint showComp(int compid) throws java.rmi.RemoteException;
    public com.java.restservices.RestComplaintService.Complaint[] showAllComp() throws java.rmi.RemoteException;
    public java.lang.String addComp(com.java.restservices.RestComplaintService.Complaint comp) throws java.rmi.RemoteException;
}
