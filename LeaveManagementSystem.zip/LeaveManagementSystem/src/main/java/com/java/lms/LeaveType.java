package com.java.lms;

public enum LeaveType {
	EL
}
