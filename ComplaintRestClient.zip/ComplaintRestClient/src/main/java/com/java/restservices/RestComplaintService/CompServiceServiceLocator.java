/**
 * CompServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.java.restservices.RestComplaintService;

public class CompServiceServiceLocator extends org.apache.axis.client.Service implements com.java.restservices.RestComplaintService.CompServiceService {

    public CompServiceServiceLocator() {
    }


    public CompServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CompServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CompService
    private java.lang.String CompService_address = "http://localhost:8080/RestComplaintService/services/CompService";

    public java.lang.String getCompServiceAddress() {
        return CompService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CompServiceWSDDServiceName = "CompService";

    public java.lang.String getCompServiceWSDDServiceName() {
        return CompServiceWSDDServiceName;
    }

    public void setCompServiceWSDDServiceName(java.lang.String name) {
        CompServiceWSDDServiceName = name;
    }

    public com.java.restservices.RestComplaintService.CompService getCompService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CompService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCompService(endpoint);
    }

    public com.java.restservices.RestComplaintService.CompService getCompService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.java.restservices.RestComplaintService.CompServiceSoapBindingStub _stub = new com.java.restservices.RestComplaintService.CompServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getCompServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCompServiceEndpointAddress(java.lang.String address) {
        CompService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.java.restservices.RestComplaintService.CompService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.java.restservices.RestComplaintService.CompServiceSoapBindingStub _stub = new com.java.restservices.RestComplaintService.CompServiceSoapBindingStub(new java.net.URL(CompService_address), this);
                _stub.setPortName(getCompServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CompService".equals(inputPortName)) {
            return getCompService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://RestComplaintService.restservices.java.com", "CompServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://RestComplaintService.restservices.java.com", "CompService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CompService".equals(portName)) {
            setCompServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
