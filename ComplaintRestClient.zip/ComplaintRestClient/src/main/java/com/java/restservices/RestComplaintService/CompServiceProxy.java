package com.java.restservices.RestComplaintService;

public class CompServiceProxy implements com.java.restservices.RestComplaintService.CompService {
  private String _endpoint = null;
  private com.java.restservices.RestComplaintService.CompService compService = null;
  
  public CompServiceProxy() {
    _initCompServiceProxy();
  }
  
  public CompServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initCompServiceProxy();
  }
  
  private void _initCompServiceProxy() {
    try {
      compService = (new com.java.restservices.RestComplaintService.CompServiceServiceLocator()).getCompService();
      if (compService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)compService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)compService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (compService != null)
      ((javax.xml.rpc.Stub)compService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.java.restservices.RestComplaintService.CompService getCompService() {
    if (compService == null)
      _initCompServiceProxy();
    return compService;
  }
  
  public com.java.restservices.RestComplaintService.Complaint showComp(int compid) throws java.rmi.RemoteException{
    if (compService == null)
      _initCompServiceProxy();
    return compService.showComp(compid);
  }
  
  public com.java.restservices.RestComplaintService.Complaint[] showAllComp() throws java.rmi.RemoteException{
    if (compService == null)
      _initCompServiceProxy();
    return compService.showAllComp();
  }
  
  public java.lang.String addComp(com.java.restservices.RestComplaintService.Complaint comp) throws java.rmi.RemoteException{
    if (compService == null)
      _initCompServiceProxy();
    return compService.addComp(comp);
  }
  
  
}