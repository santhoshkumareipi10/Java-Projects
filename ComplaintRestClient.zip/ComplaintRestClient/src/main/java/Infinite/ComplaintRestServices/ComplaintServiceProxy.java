package Infinite.ComplaintRestServices;

public class ComplaintServiceProxy implements Infinite.ComplaintRestServices.ComplaintService {
  private String _endpoint = null;
  private Infinite.ComplaintRestServices.ComplaintService complaintService = null;
  
  public ComplaintServiceProxy() {
    _initComplaintServiceProxy();
  }
  
  public ComplaintServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initComplaintServiceProxy();
  }
  
  private void _initComplaintServiceProxy() {
    try {
      complaintService = (new Infinite.ComplaintRestServices.ComplaintServiceServiceLocator()).getComplaintService();
      if (complaintService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)complaintService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)complaintService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (complaintService != null)
      ((javax.xml.rpc.Stub)complaintService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public Infinite.ComplaintRestServices.ComplaintService getComplaintService() {
    if (complaintService == null)
      _initComplaintServiceProxy();
    return complaintService;
  }
  
  public Infinite.ComplaintRestServices.Complaint[] showComplaint() throws java.rmi.RemoteException{
    if (complaintService == null)
      _initComplaintServiceProxy();
    return complaintService.showComplaint();
  }
  
  public java.lang.String addComplaint(Infinite.ComplaintRestServices.Complaint complaint) throws java.rmi.RemoteException{
    if (complaintService == null)
      _initComplaintServiceProxy();
    return complaintService.addComplaint(complaint);
  }
  
  public Infinite.ComplaintRestServices.Complaint showComplaint(int complaintID) throws java.rmi.RemoteException{
    if (complaintService == null)
      _initComplaintServiceProxy();
    return complaintService.showComplaint(complaintID);
  }
  
  
}