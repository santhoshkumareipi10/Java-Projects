/**
 * Complaint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Infinite.ComplaintRestServices;

public class Complaint  implements java.io.Serializable {
    private java.lang.String cDescription;

    private java.util.Date complaintDate;

    private int complaintID;

    private java.lang.String complaintType;

    private java.lang.String severity;

    private java.lang.String status;

    public Complaint() {
    }

    public Complaint(
           java.lang.String cDescription,
           java.util.Date complaintDate,
           int complaintID,
           java.lang.String complaintType,
           java.lang.String severity,
           java.lang.String status) {
           this.cDescription = cDescription;
           this.complaintDate = complaintDate;
           this.complaintID = complaintID;
           this.complaintType = complaintType;
           this.severity = severity;
           this.status = status;
    }


    /**
     * Gets the cDescription value for this Complaint.
     * 
     * @return cDescription
     */
    public java.lang.String getCDescription() {
        return cDescription;
    }


    /**
     * Sets the cDescription value for this Complaint.
     * 
     * @param cDescription
     */
    public void setCDescription(java.lang.String cDescription) {
        this.cDescription = cDescription;
    }


    /**
     * Gets the complaintDate value for this Complaint.
     * 
     * @return complaintDate
     */
    public java.util.Date getComplaintDate() {
        return complaintDate;
    }


    /**
     * Sets the complaintDate value for this Complaint.
     * 
     * @param complaintDate
     */
    public void setComplaintDate(java.util.Date complaintDate) {
        this.complaintDate = complaintDate;
    }


    /**
     * Gets the complaintID value for this Complaint.
     * 
     * @return complaintID
     */
    public int getComplaintID() {
        return complaintID;
    }


    /**
     * Sets the complaintID value for this Complaint.
     * 
     * @param complaintID
     */
    public void setComplaintID(int complaintID) {
        this.complaintID = complaintID;
    }


    /**
     * Gets the complaintType value for this Complaint.
     * 
     * @return complaintType
     */
    public java.lang.String getComplaintType() {
        return complaintType;
    }


    /**
     * Sets the complaintType value for this Complaint.
     * 
     * @param complaintType
     */
    public void setComplaintType(java.lang.String complaintType) {
        this.complaintType = complaintType;
    }


    /**
     * Gets the severity value for this Complaint.
     * 
     * @return severity
     */
    public java.lang.String getSeverity() {
        return severity;
    }


    /**
     * Sets the severity value for this Complaint.
     * 
     * @param severity
     */
    public void setSeverity(java.lang.String severity) {
        this.severity = severity;
    }


    /**
     * Gets the status value for this Complaint.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Complaint.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Complaint)) return false;
        Complaint other = (Complaint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cDescription==null && other.getCDescription()==null) || 
             (this.cDescription!=null &&
              this.cDescription.equals(other.getCDescription()))) &&
            ((this.complaintDate==null && other.getComplaintDate()==null) || 
             (this.complaintDate!=null &&
              this.complaintDate.equals(other.getComplaintDate()))) &&
            this.complaintID == other.getComplaintID() &&
            ((this.complaintType==null && other.getComplaintType()==null) || 
             (this.complaintType!=null &&
              this.complaintType.equals(other.getComplaintType()))) &&
            ((this.severity==null && other.getSeverity()==null) || 
             (this.severity!=null &&
              this.severity.equals(other.getSeverity()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCDescription() != null) {
            _hashCode += getCDescription().hashCode();
        }
        if (getComplaintDate() != null) {
            _hashCode += getComplaintDate().hashCode();
        }
        _hashCode += getComplaintID();
        if (getComplaintType() != null) {
            _hashCode += getComplaintType().hashCode();
        }
        if (getSeverity() != null) {
            _hashCode += getSeverity().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Complaint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "Complaint"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "cDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complaintDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "complaintDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complaintID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "complaintID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complaintType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "complaintType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("severity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "severity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
