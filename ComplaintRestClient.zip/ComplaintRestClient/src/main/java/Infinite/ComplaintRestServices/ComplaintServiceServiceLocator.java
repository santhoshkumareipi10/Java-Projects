/**
 * ComplaintServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Infinite.ComplaintRestServices;

public class ComplaintServiceServiceLocator extends org.apache.axis.client.Service implements Infinite.ComplaintRestServices.ComplaintServiceService {

    public ComplaintServiceServiceLocator() {
    }


    public ComplaintServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ComplaintServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ComplaintService
    private java.lang.String ComplaintService_address = "http://localhost:8080/ComplaintRestServices/services/ComplaintService";

    public java.lang.String getComplaintServiceAddress() {
        return ComplaintService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ComplaintServiceWSDDServiceName = "ComplaintService";

    public java.lang.String getComplaintServiceWSDDServiceName() {
        return ComplaintServiceWSDDServiceName;
    }

    public void setComplaintServiceWSDDServiceName(java.lang.String name) {
        ComplaintServiceWSDDServiceName = name;
    }

    public Infinite.ComplaintRestServices.ComplaintService getComplaintService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ComplaintService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getComplaintService(endpoint);
    }

    public Infinite.ComplaintRestServices.ComplaintService getComplaintService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            Infinite.ComplaintRestServices.ComplaintServiceSoapBindingStub _stub = new Infinite.ComplaintRestServices.ComplaintServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getComplaintServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setComplaintServiceEndpointAddress(java.lang.String address) {
        ComplaintService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (Infinite.ComplaintRestServices.ComplaintService.class.isAssignableFrom(serviceEndpointInterface)) {
                Infinite.ComplaintRestServices.ComplaintServiceSoapBindingStub _stub = new Infinite.ComplaintRestServices.ComplaintServiceSoapBindingStub(new java.net.URL(ComplaintService_address), this);
                _stub.setPortName(getComplaintServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ComplaintService".equals(inputPortName)) {
            return getComplaintService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "ComplaintServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ComplaintRestServices.Infinite", "ComplaintService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ComplaintService".equals(portName)) {
            setComplaintServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
